/**
 * all js
 * @author: Yupi Li
 */